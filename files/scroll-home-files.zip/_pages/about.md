---
permalink: /
layout: scroll-home
title: "Shrushti Sharma"
name: "Shrushti Sharma"
hero_image: /images/hero-photo.png
email: "shrushtisharma@icloud.com"
nav_links:
  - text: "about"
    anchor: "#bio"
  - text: "portfolio"
    anchor: "#portfolio"
  - text: "contact"
    anchor: "#contact"
portfolio_title: "portfolio"
portfolio_subtitle: "applied ML, econometrics and more"
portfolio_groups:
  - heading: "code"
    items:
      - text: "Bitcoin Price Forecasting"
        url: "https://github.com/sharmashrushti/bitcoin-price-forecasting"
        byline: "Time-series forecasting model for BTC price movements"
      - text: "Panel Econometrics: California Pollution & Mortality"
        url: "https://github.com/sharmashrushti/ca-pollution-mortality-analysis"
        byline: "Fixed-effects panel regression (PanelOLS/linearmodels), deployed as a Streamlit app"
      - text: "Stellar Object Classification (SDSS17)"
        url: "https://github.com/sharmashrushti/stellar-object-classification"
        byline: "XGBoost model, ~98% accuracy — deployed via Streamlit & FastAPI"
social_links:
  - platform: "github"
    url: "https://github.com/sharmashrushti"
  - platform: "linkedin"
    url: "https://www.linkedin.com/in/shrushti-sharma-8ba67541a"
  - platform: "kaggle"
    url: "https://www.kaggle.com/shrushtirsharma"
redirect_from:
  - /about/
  - /about.html
---

Hello,

I'm Shrushti. I'm an incoming MSc Finance and Investment student at the **University of Edinburgh Business School**, starting September 2026.

Before this, I completed a BCom (Honours) at the University of Delhi, picked up the NISM Series V-A and XV certifications along the way, and will finish a diploma in Data Science and AI by October 2026.

My background sits at the intersection of quantitative finance, data science, and machine learning. I've worked as a proprietary trader across equity, mutual funds, bonds, SDLs, T-bills and fixed deposits, built models ranging from stellar classification to econometric panel analysis, and spent time on the more grounded end of finance too — as a Marketing Intern at Wudmin Energy, an Accounts Intern at Infospeed Services, and a Data Science Intern at First Quadrant Labs.

My long-term goal is a PhD in Finance. I'm especially interested in household finance, behavioural finance, corporate finance, asset pricing, banking, macrofinance, computational finance, and monetary policy and financial stability. The best of my project work is listed lower down on this page.

To talk research, opportunities, or just to say hello, you can find me at [shrushtisharma@icloud.com](mailto:shrushtisharma@icloud.com).
